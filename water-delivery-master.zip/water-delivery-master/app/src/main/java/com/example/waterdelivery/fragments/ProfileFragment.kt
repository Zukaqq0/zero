package com.example.waterdelivery.fragments

import androidx.fragment.app.Fragment
import com.example.waterdelivery.R

class ProfileFragment : Fragment(R.layout.fragment_profile) {
}